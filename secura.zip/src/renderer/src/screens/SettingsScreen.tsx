import {
  ArrowLeft,
  Clock,
  Clipboard,
  Key,
  Download,
  Shield,
  ChevronRight,
  Info,
  EyeOff,
  Eye
} from 'lucide-react'
import { Button } from '../components/ui/button/button'
import { Label } from '../components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '../components/ui/select'
import { JSX, useState } from 'react'
import { useSettingsStore } from '../stores/settingsStore'
import { Input } from '../components/ui/input'
import { useMasterPasswordStore } from '../stores/masterPasswordStore'

interface SettingsScreenProps {
  onBack: () => void
}

export function SettingsScreen({ onBack }: SettingsScreenProps): JSX.Element {
  const { autoLockMinutes, clipboardSeconds, update } = useSettingsStore()

  const [showChangePassModal, setShowChangePassModal] = useState(false)
  const [oldPass, setOldPass] = useState('')
  const [newPass, setNewPass] = useState('')
  const [confirmPass, setConfirmPass] = useState('')
  const [msg, setMsg] = useState('')
  const [valid, setValid] = useState(true)
  const [loading, setLoading] = useState(false)
  const [showOldPass, setShowOldPass] = useState(false)
  const [showNewPass, setShowNewPass] = useState(false)
  const [showConfirmPass, setShowConfirmPass] = useState(false)
  const [showExportSuccess, setShowExportSuccess] = useState(false)

  const sessionKey = useMasterPasswordStore.getState().sessionKey as string
  console.log('Frontend - Session key:', sessionKey)

  if (!sessionKey) {
    console.error('No session key available!')
  }

  const handleChangePassword = async (): Promise<void> => {
    if (newPass !== confirmPass) {
      setValid(false)
      setMsg("Passwords don't match")
      return
    }
    setMsg('')
    setLoading(true)
    try {
      const success = await window.settings.changeMasterPassword(oldPass, newPass)
      if (success) {
        useMasterPasswordStore.getState().setSessionKey(success.key.toString('base64'))
        setShowChangePassModal(false)
        setOldPass('')
        setNewPass('')
        setConfirmPass('')
        setMsg('Password changed successfully!')
      } else {
        setValid(false)
        setMsg('Old password is incorrect')
      }
    } catch {
      setValid(false)
      setMsg('Failed to change password')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="h-full flex flex-col bg-background">
      {/* Header */}
      <div className="flex items-center gap-3 p-4 border-b border-border">
        <Button variant="ghost" size="icon" onClick={onBack}>
          <ArrowLeft size={18} />
        </Button>
        <h1 className="text-lg font-semibold">Settings</h1>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto scrollbar-thin">
        <div className="max-w-2xl mx-auto p-6 space-y-8">
          {/* Security Section */}
          <section className="space-y-4">
            <div className="flex items-center gap-2 text-sm font-medium text-muted-foreground uppercase tracking-wider">
              <Shield size={14} />
              Security
            </div>

            {/* Auto-lock Timeout */}
            <div className="card-elevated rounded-lg p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-muted rounded-lg">
                    <Clock size={18} className="text-muted-foreground" />
                  </div>
                  <div>
                    <Label className="text-sm font-medium">Auto-lock Timeout</Label>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      Lock vault after period of inactivity
                    </p>
                  </div>
                </div>
                <Select
                  value={String(autoLockMinutes)}
                  onValueChange={(v) => update({ autoLockMinutes: Number(v) })}
                >
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">1 minute</SelectItem>
                    <SelectItem value="5">5 minutes</SelectItem>
                    <SelectItem value="15">15 minutes</SelectItem>
                    <SelectItem value="30">30 minutes</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Clipboard Timeout */}
            <div className="card-elevated rounded-lg p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-muted rounded-lg">
                    <Clipboard size={18} className="text-muted-foreground" />
                  </div>
                  <div>
                    <Label className="text-sm font-medium">Clipboard Timeout</Label>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      Clear clipboard after copying secrets
                    </p>
                  </div>
                </div>
                <Select
                  value={String(clipboardSeconds)}
                  onValueChange={(v) => update({ clipboardSeconds: Number(v) })}
                >
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="10">10 seconds</SelectItem>
                    <SelectItem value="15">15 seconds</SelectItem>
                    <SelectItem value="30">30 seconds</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </section>

          {/* Account Section */}
          <section className="space-y-4">
            <div className="flex items-center gap-2 text-sm font-medium text-muted-foreground uppercase tracking-wider">
              <Key size={14} />
              Account
            </div>

            {/* Change Master Password */}
            <button
              className="card-elevated rounded-lg p-4 w-full hover:bg-muted/30 transition-fast"
              onClick={() => setShowChangePassModal(true)}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-muted rounded-lg">
                    <Key size={18} className="text-muted-foreground" />
                  </div>
                  <div className="text-left">
                    <span className="text-sm font-medium">Change Master Password</span>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      Update your vault encryption key
                    </p>
                  </div>
                </div>
                <ChevronRight size={18} className="text-muted-foreground" />
              </div>
            </button>

            {/* Export Vault */}
            <button
              className="card-elevated rounded-lg p-4 w-full hover:bg-muted/30 transition-fast"
              onClick={async () => {
                try {
                  const success = await window.vault.downloadVault()
                  if (success) {
                    setShowExportSuccess(true)
                    setTimeout(() => setShowExportSuccess(false), 2000)
                  }
                } catch {
                  return
                }
              }}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-muted rounded-lg">
                    <Download size={18} className="text-muted-foreground" />
                  </div>
                  <div className="text-left">
                    <span className="text-sm font-medium">Export Vault</span>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      Download encrypted backup file
                    </p>
                  </div>
                </div>
                <ChevronRight size={18} className="text-muted-foreground" />
              </div>
            </button>
          </section>

          {/* About Section */}
          <section className="space-y-4">
            <div className="flex items-center gap-2 text-sm font-medium text-muted-foreground uppercase tracking-wider">
              <Info size={14} />
              About
            </div>

            <div className="card-elevated rounded-lg p-5 space-y-4">
              <div>
                <h3 className="text-sm font-medium mb-2">Security Model</h3>
                <p className="text-xs text-muted-foreground leading-relaxed">
                  Secura encrypts all secrets locally using AES-256-GCM. Your master password never
                  leaves your device. Encryption keys are derived locally using Argon2id with strong
                  memory-hard parameters and a unique salt, making brute-force and GPU attacks
                  impractical. All data is encrypted before being written to disk, ensuring your
                  information remains private and secure at all times.
                </p>
              </div>
              <div className="pt-3 border-t border-border flex items-center justify-between text-xs text-muted-foreground">
                <span>Secura v1.0.0</span>
                <span>© {new Date().getFullYear()}</span>
              </div>
            </div>
          </section>
        </div>
      </div>

      {/* --- Overlay Modal --- */}
      {showChangePassModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
          <div className="bg-background card-elevated rounded-lg p-6 w-96 space-y-4">
            <h2 className="text-lg font-semibold">Change Master Password</h2>

            <div className="space-y-2 relative">
              <Label>Old Password</Label>
              <div className="relative">
                <Input
                  type={showOldPass ? 'text' : 'password'}
                  className="input w-full pr-10"
                  value={oldPass}
                  onChange={(e) => setOldPass(e.target.value)}
                />
                <button
                  type="button"
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground"
                  onClick={() => setShowOldPass(!showOldPass)}
                >
                  {showOldPass ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            <div className="space-y-2 relative">
              <Label>New Password</Label>
              <div className="relative">
                <Input
                  type={showNewPass ? 'text' : 'password'}
                  className="input w-full pr-10"
                  value={newPass}
                  onChange={(e) => setNewPass(e.target.value)}
                />
                <button
                  type="button"
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground"
                  onClick={() => setShowNewPass(!showNewPass)}
                >
                  {showNewPass ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            <div className="space-y-2 relative">
              <Label>Confirm New Password</Label>
              <div className="relative">
                <Input
                  type={showConfirmPass ? 'text' : 'password'}
                  className="input w-full pr-10"
                  value={confirmPass}
                  onChange={(e) => setConfirmPass(e.target.value)}
                />
                <button
                  type="button"
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground"
                  onClick={() => setShowConfirmPass(!showConfirmPass)}
                >
                  {showConfirmPass ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            {msg && <p className={`text-xs ${valid ? 'text-green-500' : 'text-red-500'}`}>{msg}</p>}

            <div className="flex justify-end gap-2 mt-2">
              <Button
                variant="ghost"
                onClick={() => {
                  setShowChangePassModal(false)
                  setOldPass('')
                  setNewPass('')
                  setConfirmPass('')
                  setMsg('')
                }}
              >
                Cancel
              </Button>
              <Button onClick={handleChangePassword} disabled={loading}>
                {loading ? 'Changing...' : 'Change Password'}
              </Button>
            </div>
          </div>
        </div>
      )}

      {showExportSuccess && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
          <div className="bg-background card-elevated rounded-lg p-6 w-96 space-y-4 text-center">
            <div className="flex justify-center">
              <div className="p-3 rounded-full bg-green-500/10">
                <Download className="text-green-500" size={28} />
              </div>
            </div>

            <h2 className="text-lg font-semibold">Export Successful</h2>

            <p className="text-sm text-muted-foreground">
              Your vault was exported successfully to your Desktop.
            </p>

            <div className="flex justify-center pt-2">
              <Button onClick={() => setShowExportSuccess(false)}>OK</Button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
